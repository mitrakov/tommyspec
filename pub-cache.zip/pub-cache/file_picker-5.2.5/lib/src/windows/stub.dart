import 'package:file_picker/file_picker.dart';

/// Stub method to support both dart:ffi and web
FilePicker filePickerWithFFI() => throw UnimplementedError('Unsupported');
